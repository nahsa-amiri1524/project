CFTR_CHROM = "chr7"
CFTR_START = 117120016
CFTR_END   = 117120045
CFTR_REF_MOTIF = "CTATCATCTTTGGTGTTTCCTATGATGA"
CFTR_MUT_MOTIF = "CTATCATCTTGGTGTTTCCTATGATGA"

HTT_CHROM = "chr4"
HTT_START = 3076600
HTT_END   = 3076700
HTT_MOTIF = "CAG"

FASTA_PATH = "hg38.fa"

def interpret_cag(n):
    if n <= 26:
        return f"normal ({n})"
    elif 27 <= n <= 35:
        return f"intermediate ({n})"
    else:
        return f"pathogenic ({n})"