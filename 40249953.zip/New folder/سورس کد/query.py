from data import *
from SE import *

def run_analysis():
    print("🔬 تحلیل ژن CFTR (فیبروز کیستیک):")
    chr7 = read_chromosome(FASTA_PATH, CFTR_CHROM)
    cftr_seq = extract_region(chr7, CFTR_START, CFTR_END)
    cftr_result = detect_cftr(cftr_seq)
    print(f"وضعیت فرد: {cftr_result}")

    print("\n🧠 تحلیل ژن HTT (هانتینگتون):")
    chr4 = read_chromosome(FASTA_PATH, HTT_CHROM)
    htt_seq = extract_region(chr4, HTT_START, HTT_END)
    cag_count = max_cag_run(htt_seq)
    htt_result = interpret_cag(cag_count)
    print(f"تعداد تکرار CAG: {cag_count}")
    print(f"وضعیت فرد: {htt_result}")

if name == "__main__":
    run_analysis()